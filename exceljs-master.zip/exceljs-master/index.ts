import * as ExcelJS from './dist/es5';
export default ExcelJS;
