---
name: 💬 Questions / Help
title: '[Q] PLEASE USE DISCUSSIONS'
label: ':speech_balloon: Question'
about: https://github.com/exceljs/exceljs/discussions/categories/q-a 
---

## 💬 Questions and Help

Please do not use issues for making a questions, for this purposes much better is GitHub Discussions feature:
https://github.com/exceljs/exceljs/discussions/categories/q-a

### How to make a question?

1. First, try to find it by using search bar - anware what are you looking for was be done before.
2. Push the `New discussion` button.
3. Select `Q&A` category.
